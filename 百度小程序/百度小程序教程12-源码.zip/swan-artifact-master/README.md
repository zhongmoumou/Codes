# swan-artifact

表白整蛊神器小程序——喜欢是放肆，爱是克制~优雅不失礼貌地与男/女神搭讪，制作属于你们的专属照片
（附百度智能小程序相关教学）

# 快速开始
> 1. 安装百度小程序开发者工具，下载地址 https://smartprogram.baidu.com/docs/develop/devtools/history/
> 2. 本地已安装node，建议 11 以上

项目根目录执行 npm i，安装项目依赖；

app.json等项目根目录作为小程序入口文件，在开发者工具中打开
