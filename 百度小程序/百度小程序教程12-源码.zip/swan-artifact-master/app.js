/**
 * @file app.js
 * @author jingxiangzheng
 */

/* globals swan, App */
/* eslint-disable babel/new-cap */
App({
/* eslint-disable babel/new-cap */
    onLaunch(options) {
        // do something when launch
    },
    onShow(options) {
        // do something when show
    },
    onHide() {
        // do something when hide
    }
});
