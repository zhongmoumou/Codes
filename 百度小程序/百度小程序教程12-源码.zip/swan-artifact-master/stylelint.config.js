module.exports = {
    extends: '@ecomfe/stylelint-config',
};
